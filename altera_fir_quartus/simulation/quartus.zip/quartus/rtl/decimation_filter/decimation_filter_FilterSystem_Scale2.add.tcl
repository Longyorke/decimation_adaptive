# This is the Quartus file list for 'decimation_filter_FilterSystem_Scale2'

set_global_assignment -name SYSTEMVERILOG_FILE G:/EM_LAB/EM_Instrument/TEMR-3S/Num01_code/Filter/altera_fir/./rtl/decimation_filter/decimation_filter_FilterSystem_Scale2.sv
set_global_assignment -name SYSTEMVERILOG_FILE G:/EM_LAB/EM_Instrument/TEMR-3S/Num01_code/Filter/altera_fir/./rtl/decimation_filter/decimation_filter_FilterSystem_Scale2.sv
set_global_assignment -name SYSTEMVERILOG_FILE G:/EM_LAB/EM_Instrument/TEMR-3S/Num01_code/Filter/altera_fir/./rtl/decimation_filter/decimation_filter_FilterSystem_Scale2.sv
set_global_assignment -name SYSTEMVERILOG_FILE G:/EM_LAB/EM_Instrument/TEMR-3S/Num01_code/Filter/altera_fir/./rtl/decimation_filter/decimation_filter_FilterSystem_Scale2.sv
